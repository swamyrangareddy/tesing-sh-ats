from datetime import datetime
from bson import ObjectId
from flask_pymongo import PyMongo

mongo = PyMongo()

class User:
    collection = 'users'

    @staticmethod
    def create(username, email, password):
        user = {
            'username': username,
            'email': email,
            'password': password,
            'created_at': datetime.utcnow()
        }
        return mongo.db[User.collection].insert_one(user)

    @staticmethod
    def find_by_id(user_id):
        return mongo.db[User.collection].find_one({'_id': ObjectId(user_id)})

    @staticmethod
    def find_by_email(email):
        return mongo.db[User.collection].find_one({'email': email})

class Recruiter:
    collection = 'recruiters'

    @staticmethod
    def create(name, email, phone, company, user_id):
        recruiter = {
            'name': name,
            'email': email,
            'phone': phone,
            'company': company,
            'created_at': datetime.utcnow(),
            'user_id': ObjectId(user_id)
        }
        return mongo.db[Recruiter.collection].insert_one(recruiter)

    @staticmethod
    def find_by_user(user_id):
        return mongo.db[Recruiter.collection].find({'user_id': ObjectId(user_id)})

class Job:
    collection = 'jobs'

    @staticmethod
    def create(title, company, location, description, requirements, salary_range, 
              job_type, status, bill_rate, visas, client, user_id):
        job = {
            'title': title,
            'company': company,
            'location': location,
            'description': description,
            'requirements': requirements,
            'salary_range': salary_range,
            'job_type': job_type,
            'status': status,
            'bill_rate': bill_rate,
            'visas': visas,
            'client': client,
            'created_at': datetime.utcnow(),
            'user_id': ObjectId(user_id)
        }
        return mongo.db[Job.collection].insert_one(job)

    @staticmethod
    def find_by_user(user_id):
        return mongo.db[Job.collection].find({'user_id': ObjectId(user_id)})

class Submission:
    collection = 'submissions'

    @staticmethod
    def create(candidate_name, candidate_email, candidate_phone, candidate_city,
              candidate_state, candidate_country, candidate_location, experience_years,
              current_company, notice_period, visa, pay_rate, status, notes,
              user_id, job_id, recruiter_id):
        submission = {
            'candidate_name': candidate_name,
            'candidate_email': candidate_email,
            'candidate_phone': candidate_phone,
            'candidate_city': candidate_city,
            'candidate_state': candidate_state,
            'candidate_country': candidate_country,
            'candidate_location': candidate_location,
            'experience_years': experience_years,
            'current_company': current_company,
            'notice_period': notice_period,
            'visa': visa,
            'pay_rate': pay_rate,
            'status': status,
            'notes': notes,
            'created_at': datetime.utcnow(),
            'user_id': ObjectId(user_id),
            'job_id': ObjectId(job_id),
            'recruiter_id': ObjectId(recruiter_id)
        }
        return mongo.db[Submission.collection].insert_one(submission)

    @staticmethod
    def find_by_user(user_id):
        return mongo.db[Submission.collection].find({'user_id': ObjectId(user_id)})

class Resume:
    collection = 'resumes'

    @staticmethod
    def create(name, email, phone_number, job_title, current_job, skills,
              location, resume_summary, experience, resume_text, resume_data,
              filename, user_id):
        resume = {
            'name': name,
            'email': email,
            'phone_number': phone_number,
            'job_title': job_title,
            'current_job': current_job,
            'skills': skills,
            'location': location,
            'resume_summary': resume_summary,
            'experience': experience,
            'resume_text': resume_text,
            'resume_data': resume_data,
            'filename': filename,
            'created_at': datetime.utcnow(),
            'user_id': ObjectId(user_id)
        }
        return mongo.db[Resume.collection].insert_one(resume)

    @staticmethod
    def find_by_user(user_id):
        return mongo.db[Resume.collection].find({'user_id': ObjectId(user_id)}) 